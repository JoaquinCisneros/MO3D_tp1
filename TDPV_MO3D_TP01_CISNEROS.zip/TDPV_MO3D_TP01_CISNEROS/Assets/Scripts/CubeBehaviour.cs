using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeBehaviour : MonoBehaviour
{   
    //Utilizo serializeField para poder modificar y ver las variables desde el inspector

    [SerializeField] private float rotationSpeed = 100f; // Velocidad de rotaci�n
    [SerializeField] private int direction = 1; // 1 para sentido normal, -1 para sentido inverso
    [SerializeField] private bool isRotating = true; // Indica si la rotaci�n est� activa

    // Cambiar sentido de rotacion
    public void SetRotationDirection(int newDirection)
    {
        direction = newDirection;
    }

    // Alternar la rotacion
    public void ToggleRotation(bool active)
    {
        isRotating = active;
    }

    // Ajustar Velocidad
    public void SetRotationSpeed(float newSpeed)
    {
        rotationSpeed = newSpeed;
    }

    void Update()
    {
        // Si la rotaci�n est� activa, rotar el cubo
        if (isRotating)
        {
            transform.Rotate(0, direction * rotationSpeed * Time.deltaTime, 0);
        }
    }
}
