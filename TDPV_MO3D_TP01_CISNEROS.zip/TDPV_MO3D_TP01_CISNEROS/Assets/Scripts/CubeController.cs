using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeController : MonoBehaviour
{
    public CubeBehaviour cubeBehaviour; // Referencia al componente CubeBehaviour
    private bool isRotating = true; // Estado inicial de la rotaci�n
    private int direction = 1; // 1 para direcci�n normal, -1 para direcci�n inversa

    void Start()
    {
        cubeBehaviour.SetRotationDirection(direction); // Direcci�n inicial
    }

    void Update()
    {
        // Espacio para cambiar la rotacion
        if (Input.GetKeyDown(KeyCode.Space))
        {
            // Alternar entre direcci�n normal (1) e inversa (-1)
            direction *= -1;
            cubeBehaviour.SetRotationDirection(direction);
        }

        // Ctrl para activar y desactivar rotacion
        if (Input.GetKeyDown(KeyCode.LeftControl) || Input.GetKeyDown(KeyCode.RightControl))
        {
            // Alternar el estado de rotaci�n
            isRotating = !isRotating;
            cubeBehaviour.ToggleRotation(isRotating);
        }
    }
}
